import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { Entypo, FontAwesome, Zocial   } from '@expo/vector-icons';  

export default function App() {
  return (
    <View style={styles.container}>
      
    {/*1ª familia*/}
      <View style={styles.familia_icones}>
        <Text style={styles.familia_titulo}>Entypo</Text>
        <View  style={styles.lista_icones}>
        <Entypo style={styles.especo_icones} name="mic" size={24} color="black" />
        <Entypo style={styles.especo_icones} name="sound-mix" size={24} color="black" />
        <Entypo style={styles.especo_icones} name="creative-commons-remix" size={24} color="black" />
        <Entypo style={styles.especo_icones} name="area-graph" size={24} color="#20B2AA" />
        <Entypo style={styles.especo_icones} name="app-store" size={24} color="#fff" />
        </View>
      </View>

    {/*2ª familia*/}
      <View style={styles.familia_icones}>
        <Text style={styles.familia_titulo}>FontAwesome </Text>
        <View  style={styles.lista_icones}>
        <FontAwesome style={styles.especo_icones} name="signal" size={24} color="green" />
        <FontAwesome style={styles.especo_icones} name="trash-o" size={24} color="#4682B4" />
        <FontAwesome style={styles.especo_icones} name="power-off" size={24} color="#8B0000" />
        <FontAwesome style={styles.especo_icones} name="video-camera" size={24} color="#6A5ACD" />
        <FontAwesome style={styles.especo_icones} name="plane" size={24} color="black" />
        </View>
      </View>

    {/*3ª familia*/}
    <View style={styles.familia_icones}>
    <Text style={styles.familia_titulo}>Zocial </Text>
    <View  style={styles.lista_icones}>
    <Zocial style={styles.especo_icones} name="yahoo" size={24} color="#4B0082" />
    <Zocial style={styles.especo_icones} name="windows" size={24} color="#1E90FF" />
    <Zocial style={styles.especo_icones} name="youtube" size={24} color="#FF0000" />
    <Zocial style={styles.especo_icones} name="spotify" size={24} color="#008000" />
    <Zocial style={styles.especo_icones} name="soundcloud" size={24} color="#FF8C00" />
    </View>
  </View>
</View>
  )};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',
    alignItems: 'center',
    justifyContent: 'center',
  },
  familia_icones:{
    backgroundColor: '#ccc',
    borderRadius: 5,
    width: '90%',
    marginBottom:20,
    padding:15
  },
  lista_icones:{
    flexDirection: 'row',
    marginTop:20
  },
  familia_titulo:{
    fontFamily: 'Franklin Gothic Medium',
    fontSize:30,
    borderStyle: 'solid',
    borderColor: '#222',
    borderBottomWidth:2
  },
  especo_icones:{
    margin:5
  }
});
